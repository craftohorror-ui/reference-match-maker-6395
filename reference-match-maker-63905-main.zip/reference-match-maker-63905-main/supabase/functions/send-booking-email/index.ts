import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@4.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface BookingRequest {
  name: string;
  email: string;
  businessName: string;
  contactNo: string;
  service: string;
  message: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, email, businessName, contactNo, service, message }: BookingRequest = await req.json();

    console.log("Processing booking request for:", email);

    // Map service values to readable names
    const serviceNames: { [key: string]: string } = {
      "ai-receptionist": "AI Receptionist",
      "outreach-agent": "Outreach Agent",
      "ai-real-estate-agent": "AI Real Estate Agent",
    };

    const serviceName = serviceNames[service] || service;

    // Send email to business owner
    const emailResponse = await resend.emails.send({
      from: "Nuvia AI <onboarding@resend.dev>",
      to: ["ayandevpro@gmail.com"],
      subject: `New Booking Request from ${name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
          <div style="background-color: #8b5cf6; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="color: white; margin: 0;">New Booking Request</h1>
          </div>
          
          <div style="background-color: white; padding: 30px; border-radius: 0 0 8px 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2 style="color: #333; margin-top: 0;">Contact Details</h2>
            
            <div style="margin: 20px 0; padding: 15px; background-color: #f5f5f5; border-radius: 5px;">
              <p style="margin: 10px 0;"><strong>Name:</strong> ${name}</p>
              <p style="margin: 10px 0;"><strong>Email:</strong> ${email}</p>
              <p style="margin: 10px 0;"><strong>Business Name:</strong> ${businessName}</p>
              <p style="margin: 10px 0;"><strong>Contact No:</strong> ${contactNo}</p>
              <p style="margin: 10px 0;"><strong>Service:</strong> ${serviceName}</p>
            </div>
            
            ${message ? `
              <h3 style="color: #333; margin-top: 25px;">Message/Call Request</h3>
              <div style="padding: 15px; background-color: #f5f5f5; border-radius: 5px; border-left: 4px solid #8b5cf6;">
                <p style="margin: 0; white-space: pre-wrap;">${message}</p>
              </div>
            ` : ''}
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; color: #666; font-size: 12px;">
              <p>This email was sent from your Nuvia AI website booking form.</p>
            </div>
          </div>
        </div>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-booking-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
