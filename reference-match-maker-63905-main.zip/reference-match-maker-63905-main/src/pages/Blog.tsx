import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { useNavigate } from "react-router-dom";
import { Mail, TrendingUp, Globe, Shield, Building, Brain, Zap } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import blogImg1 from "@/assets/blog-img-1.avif";
import blogImg2 from "@/assets/blog-img-2.avif";
import blogImg3 from "@/assets/blog-img-3.avif";
import blogImg4 from "@/assets/blog-img-4.avif";
import blogImg5 from "@/assets/blog-img-5.avif";
import blogImg6 from "@/assets/blog-img-6.avif";
import blogImg7 from "@/assets/blog-img-7.avif";
import blogHeroOffice from "@/assets/blog-hero-office.avif";
import blogFooterBg from "@/assets/blog-footer-bg.avif";
const categories = [{
  name: "AI & Technology",
  icon: Brain
}, {
  name: "Business Automation",
  icon: Zap
}, {
  name: "Voice Agent Case Studies",
  icon: TrendingUp
}, {
  name: "Future of Communication",
  icon: Globe
}];
const blogPosts = [{
  slug: "ai-voice-agents-revolutionizing-customer-support-2025",
  title: "How AI Voice Agents Are Revolutionizing Customer Support in 2025",
  excerpt: "Voice AI is no longer a concept — it's a revolution. Discover how human-like AI agents are transforming customer experiences worldwide.",
  category: "AI & Technology",
  readTime: "8 min read",
  date: "Nov 8, 2025",
  featured: true,
  image: blogImg1
}, {
  slug: "automate-business-calls-ai",
  title: "Top 7 Ways to Automate Business Calls Using Artificial Intelligence",
  excerpt: "Unlock efficiency and scale your communication with these proven AI automation strategies for modern businesses.",
  category: "Business Automation",
  readTime: "6 min read",
  date: "Nov 7, 2025",
  image: blogImg2
}, {
  slug: "psychology-human-like-ai-conversations",
  title: "The Psychology Behind Human-Like AI Conversations",
  excerpt: "Why do some AI voices feel natural while others sound robotic? Explore the science of conversational design.",
  category: "AI & Technology",
  readTime: "7 min read",
  date: "Nov 6, 2025",
  image: blogImg3
}, {
  slug: "ai-vs-human-agents-roi",
  title: "AI vs Human Agents: Which Offers Better ROI?",
  excerpt: "A comprehensive analysis of cost, efficiency, and customer satisfaction comparing AI and human support teams.",
  category: "Business Automation",
  readTime: "10 min read",
  date: "Nov 5, 2025",
  image: blogImg4
}, {
  slug: "multilingual-voice-ai-global-communication",
  title: "How Multilingual Voice AI Agents Are Changing Global Communication",
  excerpt: "Break language barriers and connect with customers worldwide using advanced multilingual AI voice technology.",
  category: "Future of Communication",
  readTime: "9 min read",
  date: "Nov 4, 2025",
  image: blogImg5
}, {
  slug: "data-security-voice-ai",
  title: "Data Security in Voice AI: What Every Business Should Know",
  excerpt: "Protect your customers and your business with these essential security practices for AI voice systems.",
  category: "AI & Technology",
  readTime: "8 min read",
  date: "Nov 3, 2025",
  image: blogImg6
}, {
  slug: "real-estate-ai-voice-agents",
  title: "Real Estate Agencies Are Turning to AI Voice Agents — Here's Why",
  excerpt: "Discover how leading real estate firms are leveraging AI to handle inquiries, schedule viewings, and close more deals.",
  category: "Voice Agent Case Studies",
  readTime: "7 min read",
  date: "Nov 2, 2025",
  image: blogImg7
}];
const Blog = () => {
  const navigate = useNavigate();
  const {
    toast
  } = useToast();
  const [email, setEmail] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const featuredPost = blogPosts.find(post => post.featured);
  const latestPosts = blogPosts.filter(post => !post.featured);
  const filteredPosts = selectedCategory ? latestPosts.filter(post => post.category === selectedCategory) : latestPosts;
  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "Subscribed successfully!",
        description: "You'll receive our latest insights in your inbox."
      });
      setEmail("");
    }
  };
  return <div className="min-h-screen bg-[#0a0a0f]">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-12 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={blogHeroOffice} 
            alt="Business Office" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0f] via-[#0a0a0f]/80 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0a0a0f]"></div>
        </div>

        <div className="container mx-auto relative z-10 text-left max-w-4xl">
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-2xl">
            Insights That Speak for The Future
          </h1>
          <p className="text-lg sm:text-xl text-white/80 mb-8 leading-relaxed max-w-2xl">
            Explore expert perspectives, trends, and ideas shaping the world of AI communication.<br />
            From intelligent voice agents to real-time automation, our blog delivers knowledge that drives innovation.
          </p>
          <form onSubmit={handleSubscribe} className="flex gap-3 max-w-md">
            <Input type="email" placeholder="Enter your email" value={email} onChange={e => setEmail(e.target.value)} className="bg-white/10 border-white/20 text-white placeholder:text-white/50 backdrop-blur-sm focus:bg-white/15 transition-all" required />
            <Button type="submit" size="lg" className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 shadow-lg shadow-purple-500/30 transition-all duration-300">
              Subscribe
            </Button>
          </form>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-12">
        <div className="container mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">Browse by Category</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {categories.map(category => {
            const Icon = category.icon;
            const isActive = selectedCategory === category.name;
            return <button key={category.name} onClick={() => setSelectedCategory(isActive ? null : category.name)} className={`p-6 rounded-2xl border-2 backdrop-blur-md transition-all duration-300 shadow-lg shadow-[0_0_25px_rgba(255,255,255,0.1)] ${isActive ? "bg-white/20 border-white/50 shadow-white/20 shadow-[0_0_35px_rgba(255,255,255,0.2)]" : "bg-white/10 border-white/30 hover:bg-white/15 hover:border-white/40 hover:shadow-white/10 hover:shadow-[0_0_30px_rgba(255,255,255,0.15)]"}`}>
                  <Icon className="w-8 h-8 mx-auto mb-3 text-white transition-opacity" />
                  <p className="text-white font-semibold text-center text-sm">{category.name}</p>
                </button>;
          })}
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {featuredPost && !selectedCategory && <section className="py-16 px-4 sm:px-6 lg:px-12">
          <div className="container mx-auto max-w-7xl">
            <h2 className="text-2xl font-bold text-white mb-10 text-center">Featured Insight</h2>
            <div className="relative rounded-[32px] overflow-hidden">
              <Card onClick={() => navigate(`/blog/${featuredPost.slug}`)} className="relative bg-gradient-to-r from-blue-400/20 via-purple-500/30 to-purple-900/60 border-0 overflow-hidden cursor-pointer hover:shadow-2xl hover:shadow-purple-500/40 transition-all duration-500 group backdrop-blur-xl rounded-[30px]">
                <div className="grid lg:grid-cols-2 gap-0 lg:min-h-[600px]">
                  <div className="relative h-80 lg:h-full overflow-hidden rounded-l-[30px]">
                    <div className="absolute inset-0 bg-gradient-radial from-white/40 via-transparent to-transparent opacity-60 blur-3xl"></div>
                    <img src={featuredPost.image} alt={featuredPost.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 relative z-10" />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-purple-900/20 z-20"></div>
                  </div>
                  <div className="p-10 lg:p-16 flex flex-col justify-center relative z-10">
                    <Badge className="mb-6 bg-white/10 backdrop-blur-sm text-purple-200 border-2 border-white/30 w-fit text-xs font-semibold rounded-2xl px-4 py-1.5">
                      {featuredPost.category}
                    </Badge>
                    <h3 className="text-3xl lg:text-5xl font-bold text-white mb-6 group-hover:text-purple-200 transition-colors leading-tight">
                      {featuredPost.title}
                    </h3>
                    <p className="text-lg lg:text-xl text-white/80 mb-8 leading-relaxed">
                      {featuredPost.excerpt}
                    </p>
                    <div className="flex items-center gap-4 text-sm text-white/60 mb-8">
                      <span>{featuredPost.date}</span>
                      <span>•</span>
                      <span>{featuredPost.readTime}</span>
                    </div>
                    <Button className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white shadow-lg shadow-purple-500/40 transition-all duration-300 w-fit px-8 rounded-2xl backdrop-blur-sm border-2 border-white/20">
                      Read Full Article
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </section>}

      {/* Latest Blog Posts Grid */}
      <section className="py-12 px-4 sm:px-6 lg:px-12">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">
            {selectedCategory ? `${selectedCategory} Articles` : "Latest Insights"}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map(post => <Card key={post.slug} onClick={() => navigate(`/blog/${post.slug}`)} className="bg-white/10 backdrop-blur-sm border-2 border-fuchsia-500/40 overflow-hidden cursor-pointer hover:bg-white/15 hover:border-fuchsia-400/70 transition-all duration-300 group rounded-2xl shadow-[0_0_25px_rgba(255,255,255,0.1)] hover:shadow-[0_0_35px_rgba(255,255,255,0.15)]">
                <div className="relative h-48 overflow-hidden">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] to-transparent"></div>
                  <Badge className="absolute top-4 left-4 bg-purple-500/20 backdrop-blur-sm text-purple-300 border-purple-500/30 text-xs">
                    {post.category}
                  </Badge>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-300 transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-white/80 mb-4 text-sm line-clamp-3">{post.excerpt}</p>
                  <div className="flex items-center gap-3 text-xs text-white/60 mb-4">
                    <span>{post.date}</span>
                    <span>•</span>
                    <span>{post.readTime}</span>
                  </div>
                  <Button variant="link" className="text-purple-400 hover:text-purple-300 p-0 h-auto font-semibold">
                    Read More →
                  </Button>
                </div>
              </Card>)}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-12">
        <div className="container mx-auto max-w-4xl">
          <Card className="bg-gradient-to-b from-purple-900/40 via-purple-900/20 to-[#0a0a0f] backdrop-blur-sm border-0 p-8 lg:p-12 text-center rounded-2xl">
            <Mail className="w-12 h-12 text-purple-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white mb-4">Stay Ahead of the AI Revolution</h2>
            <p className="text-white/70 mb-6 max-w-2xl mx-auto leading-relaxed">
              Join thousands of business owners transforming communication with AI voice agents.<br />
              Get our latest insights, success stories, and technology updates straight to your inbox.
            </p>
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input type="email" placeholder="Your email" value={email} onChange={e => setEmail(e.target.value)} className="bg-white/10 backdrop-blur-sm border-white/20 text-white placeholder:text-white/50 focus:bg-white/15 transition-all rounded-xl" required />
              <Button type="submit" size="lg" className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 shadow-lg shadow-purple-500/30 transition-all duration-300 rounded-xl">
                Get Updates
              </Button>
            </form>
          </Card>
        </div>
      </section>

      {/* Why Our Blog Matters */}
      <section className="py-16 px-4 sm:px-6 lg:px-12">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Why Our Blog Matters</h2>
          <p className="text-lg text-white/70 leading-relaxed mb-8">
            Every article is written by experts in AI voice technology and conversational automation.<br />
            Our insights come from real-world data, client case studies, and years of innovation in the voice AI industry.<br />
            Whether you're an entrepreneur, developer, or marketer — this is your trusted source for the future of AI-driven communication.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Badge variant="glass" className="px-4 py-2">
              AI voice technology experts
            </Badge>
            <Badge variant="glass" className="px-4 py-2">
              Conversational AI insights
            </Badge>
            <Badge variant="glass" className="px-4 py-2">
              AI automation blog
            </Badge>
          </div>
        </div>
      </section>

      {/* Closing CTA with Background Image */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-12 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={blogFooterBg} 
            alt="Background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/60 to-transparent"></div>
        </div>
        
        <div className="container mx-auto max-w-4xl text-center relative z-10">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Experience the Power of AI Voice in Action
          </h2>
          <p className="text-lg text-white/70 mb-8 leading-relaxed">
            Turn everything you've learned into reality.<br />
            Let our voice agents handle your calls, while you focus on growth.
          </p>
          <Button size="lg" onClick={() => {
          const element = document.getElementById("contact");
          if (element) {
            window.scrollTo({
              top: element.getBoundingClientRect().top + window.pageYOffset - 80,
              behavior: "smooth"
            });
          } else {
            navigate("/#contact");
          }
        }} className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white shadow-xl shadow-purple-500/30 transition-all duration-300 rounded-xl px-8">
            Book a Free Demo
          </Button>
        </div>
      </section>

      <Footer />
    </div>;
};
export default Blog;