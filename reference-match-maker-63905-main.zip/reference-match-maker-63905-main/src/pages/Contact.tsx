import { useState } from "react";
import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Phone, Clock, MapPin, Send, Sparkles, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import contactHeroBg from "@/assets/contact-hero-bg.avif";
import contactFooterBg from "@/assets/contact-footer-bg.avif";
const Contact = () => {
  const {
    toast
  } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    business: "",
    subject: "",
    message: ""
  });
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const {
        error
      } = await supabase.functions.invoke("send-booking-email", {
        body: {
          name: formData.name,
          email: formData.email,
          phone: formData.business,
          company: formData.subject,
          message: formData.message,
          type: "contact"
        }
      });
      if (error) throw error;
      setSubmitted(true);
      toast({
        title: "Message Sent!",
        description: "Our team will respond within 12 hours."
      });
      setFormData({
        name: "",
        email: "",
        business: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  return <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative py-24 sm:py-32 overflow-hidden">
        <div className="absolute inset-0 z-0" style={{
        backgroundImage: `url(${contactHeroBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}>
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f]/80 via-[#1a1a2e]/70 to-[#0a0a0f]"></div>
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 max-w-7xl relative z-10">
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="absolute inset-0 bg-accent/20 rounded-full blur-xl animate-pulse" />
              <Mail className="w-16 h-16 text-accent relative z-10" />
            </div>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-center text-foreground mb-6 leading-tight">
            Let's <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-primary">Talk</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground text-center max-w-3xl mx-auto mb-4 leading-relaxed">
            Whether you need product support, technical guidance, or a custom demo — our team is ready to assist you 24/7.
          </p>
          
          <p className="text-base sm:text-lg text-muted-foreground text-center max-w-2xl mx-auto leading-relaxed">
            We combine the precision of AI with the empathy of real people. Tell us what you need, and we'll make sure the right expert gets back to you quickly.
          </p>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="py-16 sm:py-20 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 max-w-7xl">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              {submitted ? <div className="bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm border border-border rounded-3xl p-8 sm:p-12 text-center">
                  <CheckCircle2 className="w-20 h-20 text-primary mx-auto mb-6 animate-pulse" />
                  <h3 className="text-3xl font-bold text-foreground mb-4">Thank You for Reaching Out!</h3>
                  <p className="text-lg text-muted-foreground mb-6">
                    Our team will respond within 12 hours.
                  </p>
                  <p className="text-base text-muted-foreground mb-8">
                    For urgent requests, please email us directly at <span className="text-primary font-semibold">support@nuvia.ai</span>
                  </p>
                  <Button onClick={() => setSubmitted(false)} className="button-3d px-8 py-6 rounded-2xl">
                    Send Another Message
                  </Button>
                </div> : <form onSubmit={handleSubmit} className="bg-gradient-to-b from-[#1e1e3f]/95 via-[#1a1a35]/90 to-[#16162a]/85 backdrop-blur-xl rounded-3xl p-8 sm:p-12 space-y-6 shadow-[0_20px_60px_rgba(30,30,63,0.5)]">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-foreground text-base">Name *</Label>
                    <Input id="name" value={formData.name} onChange={e => setFormData({
                  ...formData,
                  name: e.target.value
                })} className="bg-input border-border text-foreground h-12 rounded-xl focus:border-primary transition-colors" placeholder="Your full name" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-foreground text-base">Email *</Label>
                    <Input id="email" type="email" value={formData.email} onChange={e => setFormData({
                  ...formData,
                  email: e.target.value
                })} className="bg-input border-border text-foreground h-12 rounded-xl focus:border-primary transition-colors" placeholder="your.email@company.com" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="business" className="text-foreground text-base">Business Name</Label>
                    <Input id="business" value={formData.business} onChange={e => setFormData({
                  ...formData,
                  business: e.target.value
                })} className="bg-input border-border text-foreground h-12 rounded-xl focus:border-primary transition-colors" placeholder="Your company name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject" className="text-foreground text-base">Subject *</Label>
                    <Select value={formData.subject} onValueChange={value => setFormData({
                  ...formData,
                  subject: value
                })} required>
                      <SelectTrigger className="bg-input border-border text-foreground h-12 rounded-xl focus:border-primary">
                        <SelectValue placeholder="Select a topic" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="support">Support</SelectItem>
                        <SelectItem value="sales">Sales</SelectItem>
                        <SelectItem value="demo">Demo Request</SelectItem>
                        <SelectItem value="partnership">Partnership</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-foreground text-base">Message *</Label>
                    <Textarea id="message" value={formData.message} onChange={e => setFormData({
                  ...formData,
                  message: e.target.value
                })} className="bg-input border-border text-foreground min-h-[150px] rounded-xl focus:border-primary transition-colors" placeholder="Tell us how we can help..." required />
                  </div>

                  <Button type="submit" disabled={isSubmitting} className="button-3d w-full text-lg py-6 rounded-2xl group">
                    {isSubmitting ? "Sending..." : <>
                        <Send className="mr-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                        Send Message
                      </>}
                  </Button>
                </form>}
            </div>

            {/* Contact Information Sidebar */}
            <div className="space-y-6">
              <div className="bg-white/5 backdrop-blur-xl border-2 border-white/20 rounded-2xl p-6 shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
                <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Contact Information
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Mail className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Support Email</p>
                      <a href="mailto:support@nuvia.ai" className="text-foreground hover:text-primary transition-colors">
                        support@nuvia.ai
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Mail className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Sales Email</p>
                      <a href="mailto:sales@nuvia.ai" className="text-foreground hover:text-accent transition-colors">
                        sales@nuvia.ai
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Working Hours</p>
                      <p className="text-foreground">24/7 Voice Support</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-primary/10 to-accent/10 backdrop-blur-sm border border-primary/20 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Serving Businesses Worldwide
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Our AI voice solutions are trusted by companies across the US, UK, India, and Europe — powering seamless communication at scale.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Closing CTA Section */}
      <section className="py-16 sm:py-20 lg:py-24 relative overflow-hidden">
        <div className="absolute inset-0 z-0" style={{
        backgroundImage: `url(${contactFooterBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f]/90 via-[#1a1a2e]/70 to-[#0a0a0f]/80"></div>
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 max-w-4xl relative z-10">
          <div className="bg-white/5 backdrop-blur-xl border-2 border-white/20 rounded-3xl p-8 sm:p-12 text-center shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
            
            
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Experience the Future of Support
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              We're not just automating calls — we're revolutionizing communication. Let's create smarter, more personal experiences together.
            </p>
            
            <Link to="/">
              <Button className="button-3d text-lg px-10 py-6 rounded-2xl">
                <Phone className="mr-2 h-5 w-5" />
                Book a Free Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>;
};
export default Contact;