import { useState } from "react";
import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { MessageCircleQuestion, Sparkles, Shield, Zap, Globe, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

const FAQ = () => {
  const [activeCategory, setActiveCategory] = useState("all");

  const categories = [
    { id: "all", name: "All Questions", icon: Sparkles },
    { id: "understanding", name: "Understanding AI", icon: MessageCircleQuestion },
    { id: "integration", name: "Integration & Setup", icon: Settings },
    { id: "performance", name: "Performance & Support", icon: Shield },
    { id: "pricing", name: "Pricing & Demo", icon: Zap },
  ];

  const faqs = [
    {
      category: "understanding",
      question: "What exactly is an AI Voice Agent?",
      answer: "An AI voice agent is a smart, conversational system that handles customer calls, books appointments, and provides support — all using natural, human-like speech powered by advanced AI."
    },
    {
      category: "understanding",
      question: "Does your AI sound robotic?",
      answer: "Not at all. Our agents are trained with natural tone variation, pauses, and emotions — so they sound and feel human in every conversation."
    },
    {
      category: "understanding",
      question: "Can the voice agent handle multiple languages?",
      answer: "Yes. Our AI supports English, Hindi, Spanish, Mandarin, and more — adapting tone and phrasing for each language."
    },
    {
      category: "integration",
      question: "How do I integrate the voice agent into my business system?",
      answer: "We provide seamless API and CRM integrations (HubSpot, Salesforce, Google Sheets, etc.), so setup takes less than 30 minutes."
    },
    {
      category: "integration",
      question: "Can I customize what my AI says?",
      answer: "Yes — every response, tone, and behavior can be tailored to match your brand's voice and personality."
    },
    {
      category: "integration",
      question: "Do I need technical knowledge to use it?",
      answer: "Not at all. Our dashboard is built for business owners, not engineers. You can manage scripts, leads, and reports with a few clicks."
    },
    {
      category: "performance",
      question: "How reliable are your AI voice agents?",
      answer: "Our system operates with 99.9% uptime, backed by real-time monitoring. You'll never miss a call or lead."
    },
    {
      category: "performance",
      question: "Is my customer data secure?",
      answer: "Absolutely. Every call is encrypted end-to-end, and our systems comply with global data protection laws (GDPR, CCPA)."
    },
    {
      category: "performance",
      question: "What if I need human support?",
      answer: "You can reach our support team 24/7 via email or live chat. We also offer onboarding assistance for new clients."
    },
    {
      category: "pricing",
      question: "Do you offer a free demo?",
      answer: "Yes! You can schedule a live demo and experience how our AI voice agent handles real calls."
    },
    {
      category: "pricing",
      question: "How much does it cost?",
      answer: "Pricing depends on call volume and features. We offer flexible plans for startups, SMEs, restaurants, dentists, and enterprises."
    },
  ];

  const filteredFaqs = activeCategory === "all" 
    ? faqs 
    : faqs.filter(faq => faq.category === activeCategory);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative py-24 sm:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-background to-background" />
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 max-w-7xl relative z-10">
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse" />
              <MessageCircleQuestion className="w-16 h-16 text-primary relative z-10" />
            </div>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-center text-foreground mb-6 leading-tight">
            Your Questions, <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Answered</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground text-center max-w-3xl mx-auto mb-8 leading-relaxed">
            We believe clarity builds trust. Here you'll find answers to the most common questions about our AI voice agents — how they work, how they integrate, and how they help your business grow.
          </p>
          
          <div className="flex justify-center">
            <Link to="/contact">
              <Button className="button-3d text-lg px-8 py-6 rounded-2xl">
                Didn't find your question? Contact Support
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 bg-card/30 backdrop-blur-sm border-y border-border">
        <div className="container mx-auto px-4 sm:px-6 max-w-7xl">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => {
              const Icon = category.icon;
              const isActive = activeCategory === category.id;
              
              return (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={`
                    flex items-center gap-2 px-6 py-3 rounded-2xl border backdrop-blur-sm
                    transition-all duration-300 group
                    ${isActive 
                      ? 'bg-gradient-to-r from-primary to-accent text-primary-foreground border-primary shadow-lg shadow-primary/30' 
                      : 'bg-card/50 border-border text-muted-foreground hover:border-primary/50 hover:text-foreground'
                    }
                  `}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'animate-pulse' : 'group-hover:scale-110 transition-transform'}`} />
                  <span className="font-medium">{category.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ Accordion Section */}
      <section className="py-16 sm:py-20 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 max-w-4xl">
          <Accordion type="single" collapsible className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm border border-border rounded-2xl px-6 overflow-hidden hover:border-primary/50 transition-all duration-300"
              >
                <AccordionTrigger className="text-left text-lg font-semibold text-foreground hover:text-primary py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground leading-relaxed pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Still Have Questions Section */}
      <section className="py-16 sm:py-20 lg:py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent" />
        
        <div className="container mx-auto px-4 sm:px-6 max-w-4xl relative z-10">
          <div className="bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm border border-border rounded-3xl p-8 sm:p-12 text-center shadow-2xl">
            <Globe className="w-16 h-16 text-primary mx-auto mb-6 animate-pulse" />
            
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Still Have Questions?
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              We're here to help. Whether you're curious about setup, pricing, or integrations — our team is one message away.
            </p>
            
            <Link to="/contact">
              <Button className="button-3d text-lg px-10 py-6 rounded-2xl">
                <MessageCircleQuestion className="mr-2 h-5 w-5" />
                Contact Support
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default FAQ;
