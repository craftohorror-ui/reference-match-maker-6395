import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import LogoSection from "@/components/LogoSection";
import FeaturesIntro from "@/components/FeaturesIntro";
import FeatureHighlights from "@/components/FeatureHighlights";
import TestimonialSection from "@/components/TestimonialSection";
import FAQSection from "@/components/FAQSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navigation />
      <HeroSection />
      <LogoSection />
      <FeaturesIntro />
      <FeatureHighlights />
      <TestimonialSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default Index;
