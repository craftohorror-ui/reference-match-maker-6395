import { Button } from "@/components/ui/button";
import { Brain, Headphones, Shield, Zap, Globe, Mic } from "lucide-react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BookingDialog from "@/components/BookingDialog";
import techOffice from "@/assets/tech-office.png";
import techDashboard from "@/assets/tech-dashboard.png";
import techControlRoom from "@/assets/tech-control-room.png";
import techTeam from "@/assets/tech-team.png";
import techWorkspace from "@/assets/tech-workspace.png";
import heroTechTeam from "@/assets/hero-tech-team.png";
import ctaTechOffice from "@/assets/cta-tech-office.png";
import featureVoiceNeon from "@/assets/feature-voice-neon.jpg";
import featureAvailabilityNeon from "@/assets/feature-availability-neon.jpg";
import featureCrmNeon from "@/assets/feature-crm-neon.jpg";
import featureMultilingualNeon from "@/assets/feature-multilingual-neon.jpg";
import featureReliabilityNeon from "@/assets/feature-reliability-neon.jpg";
import featureSecurityNeon from "@/assets/feature-security-neon.jpg";
const About = () => {
  return <div className="min-h-screen bg-[#0a0a0f]">
      <Navigation />
      
      {/* Hero Section - Who We Are */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroTechTeam} alt="AI Technology Team" className="w-full h-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f]/40 via-[#0a0a0f]/60 to-[#0a0a0f]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(147,51,234,0.1),transparent_50%)]"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="mb-8 flex justify-center">
              <div className="relative">
                <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center backdrop-blur-sm border border-primary/30">
                  <Mic className="w-10 h-10 text-primary" />
                </div>
                <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping"></div>
              </div>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
              Reinventing Conversations with the Power of AI
            </h1>
            
            <p className="text-xl sm:text-2xl text-muted-foreground mb-8 font-semibold">
              We're not just building voice agents — we're redefining how businesses talk to people.
            </p>
            
            <p className="text-base sm:text-lg text-muted-foreground leading-relaxed max-w-3xl mx-auto">
              At Nuvia AI, we believe real communication drives real growth. Our AI voice agents sound and feel human — answering calls, booking appointments, and handling clients with warmth, empathy, and precision. Behind every "Hello," there's intelligent automation making your business faster, friendlier, and more efficient.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20 sm:py-32 bg-[#0a0a0f]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
                Our Journey
              </h2>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-6">
                It began with one simple question — "Why do most businesses still waste time answering repetitive calls?"
              </p>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-6">
                Our founders combined AI innovation with human conversation design to create voice agents that could think, talk, and solve problems — all in real time.
              </p>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                Today, we help companies across industries automate communication while keeping the warmth of a real human touch.
              </p>
            </div>
            
            <div className="relative rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent"></div>
              <img src={techControlRoom} alt="Advanced AI technology control room" className="w-full h-full object-cover rounded-2xl border border-border/50" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-20 sm:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-[#0a0a0f]"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 lg:gap-16 max-w-6xl mx-auto">
            <div className="p-8 sm:p-10 bg-[#0a0a0f] rounded-2xl border border-white/20 backdrop-blur-md hover:border-white/30 transition-all duration-300 shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
                Our Mission
              </h2>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                To make intelligent, human-sounding AI voice agents accessible to every business — so teams can focus on strategy, not phone calls.
              </p>
            </div>
            
            <div className="p-8 sm:p-10 bg-[#0a0a0f] rounded-2xl border border-white/20 backdrop-blur-md hover:border-white/30 transition-all duration-300 shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
                Our Vision
              </h2>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                A world where every customer interaction feels personal, instant, and effortless — powered by AI that listens, learns, and responds with empathy.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-20 sm:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/20 via-primary/10 to-[#0a0a0f] rounded-[40px] mx-4 sm:mx-6"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center max-w-7xl mx-auto">
            <div className="order-2 lg:order-1">
              <div className="mb-8">
                
              </div>
              
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-8">
                Built with the Most Advanced Voice AI
              </h2>
              
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-6">
                Our voice agents use cutting-edge speech synthesis, NLP, and emotional tone mapping to create natural, flowing conversations.
              </p>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-6">
                Every response adapts to user intent, language, and tone — creating experiences that feel alive and responsive.
              </p>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                From appointment scheduling to lead qualification, our AI handles calls end-to-end with remarkable accuracy.
              </p>
            </div>
            
            <div className="order-1 lg:order-2 grid grid-cols-2 gap-4">
              <div className="rounded-2xl overflow-hidden border border-border/50">
                <img src={techWorkspace} alt="Futuristic AI workspace" className="w-full h-full object-cover" />
              </div>
              <div className="rounded-2xl overflow-hidden border border-border/50 mt-8">
                <img src={techDashboard} alt="AI analytics dashboard" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 sm:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-[#0a0a0f]"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4"> Why Businesses Choose Us</h2>
            <p className="text-lg sm:text-xl text-muted-foreground">
              Innovation, reliability, and results — all in one voice.
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            <div className="group bg-card/50 rounded-lg border border-border backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <div className="relative h-48 overflow-hidden">
                <img src={featureVoiceNeon} alt="Human-Like Voice Precision" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <Mic className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  Human-Like Voice Precision
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our AI agents sound natural — not robotic. Trained on advanced speech models, they understand tone, emotion, and intent in real time.
                </p>
              </div>
            </div>
            
            <div className="group bg-card/50 rounded-lg border border-border backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <div className="relative h-48 overflow-hidden">
                <img src={featureAvailabilityNeon} alt="24/7 Availability" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <Zap className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  24/7 Availability
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Never miss a call again. Our AI voice agents work around the clock, handling customers while your team focuses on growth.
                </p>
              </div>
            </div>
            
            <div className="group bg-card/50 rounded-lg border border-border backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <div className="relative h-48 overflow-hidden">
                <img src={featureCrmNeon} alt="Seamless CRM Integration" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <Brain className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  Seamless CRM Integration
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Instantly connect with your existing systems — from HubSpot to Google Sheets — for automatic call logging and data syncing.
                </p>
              </div>
            </div>
            
            <div className="group bg-card/50 rounded-lg border border-border backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <div className="relative h-48 overflow-hidden">
                <img src={featureMultilingualNeon} alt="Multilingual Intelligence" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <Globe className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  Multilingual Intelligence
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Your customers speak many languages. So do we. Our agents communicate fluently in English, Hindi, Spanish, Chinese, and more.
                </p>
              </div>
            </div>
            
            <div className="group bg-card/50 rounded-lg border border-border backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <div className="relative h-48 overflow-hidden">
                <img src={featureReliabilityNeon} alt="Proven Reliability" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <Headphones className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  Proven Reliability
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Used by top businesses across industries — from healthcare to real estate — delivering measurable efficiency and conversion boosts.
                </p>
              </div>
            </div>
            
            <div className="group bg-card/50 rounded-lg border border-border backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_40px_rgba(255,255,255,0.15)]">
              <div className="relative h-48 overflow-hidden">
                <img src={featureSecurityNeon} alt="Secure & Compliant" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <Shield className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  Secure & Compliant
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Data privacy and security are built into our core. Every call is encrypted, and every interaction complies with global standards.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Closing CTA Section */}
      <section className="py-20 sm:py-32 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={ctaTechOffice} alt="AI technology office" className="w-full h-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/50 to-transparent"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.15),transparent_70%)]"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="mb-8 flex justify-center">
              <div className="relative">
                <Mic className="w-16 h-16 text-primary animate-pulse" />
                <div className="absolute inset-0 bg-primary/30 rounded-full blur-2xl"></div>
              </div>
            </div>
            
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Let's Redefine Communication Together
            </h2>
            
            <p className="text-lg sm:text-xl text-muted-foreground mb-10 leading-relaxed">
              Ready to experience what intelligent calling can do for your business? Our AI voice agents are waiting to start the conversation.
            </p>
            
            <BookingDialog>
              <Button size="lg" className="text-base sm:text-lg px-8 py-6">
                Book a Call Now
              </Button>
            </BookingDialog>
          </div>
        </div>
      </section>

      <Footer />
    </div>;
};
export default About;