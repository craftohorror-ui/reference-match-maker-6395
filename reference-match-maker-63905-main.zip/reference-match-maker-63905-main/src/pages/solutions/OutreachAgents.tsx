import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BookingDialog from "@/components/BookingDialog";
import { Button } from "@/components/ui/button";
import { Target, TrendingUp, Globe, BarChart, Zap, MessageSquare } from "lucide-react";
const OutreachAgents = () => {
  return <div className="min-h-screen bg-[#0a0a0f]">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/20 via-transparent to-transparent"></div>
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="text-center space-y-6">
            <div className="inline-block p-3 bg-blue-500/10 rounded-2xl backdrop-blur-sm border border-blue-500/20 mb-4">
              
            </div>
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-white via-blue-200 to-blue-400 bg-clip-text text-transparent">
              Smart Outreach. Real Conversations.
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Nuvia AI's Outreach Agents connect, follow up, and convert —<br />
              engaging your prospects with real-time voice conversations that feel personal and natural.
            </p>
            <BookingDialog>
              <Button size="lg" className="button-3d text-lg px-8 py-6">
                Request a Demo
              </Button>
            </BookingDialog>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-gradient-to-br from-orange-900/10 to-red-900/10 rounded-3xl p-12 backdrop-blur-sm border border-orange-500/10">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Outreach at Scale — Without the Burnout
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl">
              Manual cold calling drains teams and wastes hours on low-quality leads.<br />
              Our AI voice agents do it smarter — qualifying leads, handling objections, and booking calls automatically.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent via-blue-900/5 to-transparent">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
            How Nuvia AI Outreach Works
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[{
            step: "1",
            title: "Import or connect your lead list (CRM, CSV, or API)",
            icon: Target
          }, {
            step: "2",
            title: "The AI calls each contact with a personalized pitch",
            icon: MessageSquare
          }, {
            step: "3",
            title: "It listens, understands intent, and responds dynamically",
            icon: Zap
          }, {
            step: "4",
            title: "Books qualified calls directly into your calendar",
            icon: TrendingUp
          }].map(item => <div key={item.step} className="relative group">
                <div className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-2xl p-8 backdrop-blur-sm border border-blue-500/20 hover:border-blue-500/40 transition-all duration-300 h-full">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-500/30 transition-colors">
                    <item.icon className="w-6 h-6 text-blue-400" />
                  </div>
                  <div className="text-5xl font-bold text-blue-500/30 mb-4">{item.step}</div>
                  <p className="text-lg text-gray-200">{item.title}</p>
                </div>
              </div>)}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
            Outreach, Reimagined.
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[{
            title: "Scale Effortlessly",
            description: "Reach hundreds of leads daily without increasing headcount.",
            icon: TrendingUp
          }, {
            title: "Human-like Pacing",
            description: "Natural tone, pauses, and empathy in every call.",
            icon: MessageSquare
          }, {
            title: "Real-Time Feedback",
            description: "Track conversion rates and lead quality instantly.",
            icon: BarChart
          }, {
            title: "Multilingual Capability",
            description: "Engage clients across regions in their native language.",
            icon: Globe
          }, {
            title: "Data-Driven Optimization",
            description: "Continuous improvement with advanced analytics.",
            icon: Target
          }, {
            title: "Instant Response",
            description: "Connect with leads in seconds, not hours.",
            icon: Zap
          }].map((benefit, index) => <div key={index} className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-2xl p-8 backdrop-blur-sm border border-blue-500/20 hover:border-blue-500/40 transition-all duration-300 group">
                <div className="w-14 h-14 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-500/30 transition-colors">
                  <benefit.icon className="w-7 h-7 text-blue-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">{benefit.title}</h3>
                <p className="text-gray-300 leading-relaxed">{benefit.description}</p>
              </div>)}
          </div>
        </div>
      </section>

      {/* Case Study Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-blue-900/10 to-transparent">
        <div className="container mx-auto max-w-4xl">
          <div className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 rounded-3xl p-12 backdrop-blur-sm border border-blue-500/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
            <div className="relative z-10">
              <div className="text-6xl text-blue-400 mb-6">"</div>
              <p className="text-2xl text-gray-200 mb-8 leading-relaxed italic">
                With Nuvia AI Outreach Agents, our lead response time dropped from 48 hours to under 5 minutes. 
                Clients thought they were speaking to a real rep.
              </p>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full"></div>
                <div>
                  <p className="text-white font-semibold text-lg">Lucas Rivera</p>
                  <p className="text-gray-400">Growth Manager, ProConnect</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Start More Conversations. Close More Deals.
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Let our AI agents handle outreach while your sales team focuses on closing.
          </p>
          <BookingDialog>
            <Button size="lg" className="button-3d text-lg px-8 py-6">
              Schedule an Outreach Demo
            </Button>
          </BookingDialog>
        </div>
      </section>

      <Footer />
    </div>;
};
export default OutreachAgents;