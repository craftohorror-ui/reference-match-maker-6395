import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BookingDialog from "@/components/BookingDialog";
import { Button } from "@/components/ui/button";
import { Clock, CheckCircle, Users, Shield, Sparkles, Phone } from "lucide-react";
import receptionHeroBg from "@/assets/reception-hero-bg.avif";
import receptionFooterBg from "@/assets/reception-footer-bg.avif";
import benefit247 from "@/assets/reception-benefit-247.avif";
import benefitHuman from "@/assets/reception-ai-head.png";
import benefitData from "@/assets/reception-benefit-data.avif";
import benefitCost from "@/assets/reception-neon-lines.jpg";
import benefitCustom from "@/assets/reception-benefit-custom-new.jpeg";
import benefitIntegration from "@/assets/reception-benefit-integration.avif";

const ReceptionAgents = () => {
  return <div className="min-h-screen bg-[#0a0a0f]">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={receptionHeroBg} 
            alt="Reception background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-purple-900/80 via-[#0a0a0f]/70 to-[#0a0a0f]"></div>
        </div>
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="text-center space-y-6">
            <div className="inline-block p-3 bg-purple-500/10 rounded-2xl backdrop-blur-sm border border-purple-500/20 mb-4">
              
            </div>
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-white via-purple-200 to-purple-400 bg-clip-text text-transparent">
              Your 24/7 Receptionist — Powered by AI
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Meet Nuvia AI's Reception Agents: intelligent, polite, and always on time.<br />
              They answer calls, greet clients, and schedule appointments — instantly and naturally.
            </p>
            <BookingDialog>
              <Button size="lg" className="button-3d text-lg px-8 py-6">
                Book a Free Demo
              </Button>
            </BookingDialog>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-gradient-to-br from-red-900/10 to-orange-900/10 rounded-3xl p-12 backdrop-blur-sm border border-red-500/10">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              The Modern Reception Problem
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl">
              Missed calls mean missed opportunities.<br />
              Human receptionists can only handle one call at a time, need breaks, and can't work 24/7.<br />
              That's where Nuvia AI steps in — ensuring no lead is ever lost again.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent via-purple-900/5 to-transparent">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
            How Nuvia AI Reception Agents Work
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[{
            step: "1",
            title: "Instantly answers incoming calls",
            icon: Phone
          }, {
            step: "2",
            title: "Greets clients using your business name and tone",
            icon: Users
          }, {
            step: "3",
            title: "Handles appointment scheduling or directs calls",
            icon: Clock
          }, {
            step: "4",
            title: "Collects caller details and logs them into your CRM",
            icon: CheckCircle
          }].map(item => <div key={item.step} className="relative group">
                <div className="bg-card/50 backdrop-blur-sm rounded-2xl p-8 border border-border/50 hover:border-border transition-all duration-300 h-full flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-muted/30 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-muted/50 transition-colors">
                    <item.icon className="w-8 h-8 text-foreground" />
                  </div>
                  <p className="text-lg text-foreground font-medium">{item.title}</p>
                </div>
              </div>)}
          </div>
        </div>
      </section>

      {/* Key Benefits Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
            Why Businesses Choose Nuvia Reception Agents
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[{
            title: "Always Available",
            description: "Operates 24/7, 365 days a year.",
            icon: Clock,
            image: benefit247
          }, {
            title: "Human-Like Conversations",
            description: "Voices that sound real, warm, and empathetic.",
            icon: Users,
            image: benefitHuman
          }, {
            title: "Error-Free Data",
            description: "Every call is logged perfectly into your system.",
            icon: CheckCircle,
            image: benefitData
          }, {
            title: "Cost-Effective",
            description: "No salaries, breaks, or missed calls.",
            icon: Sparkles,
            image: benefitCost
          }, {
            title: "Fully Customizable",
            description: "Personalized greetings and workflows.",
            icon: Shield,
            image: benefitCustom
          }, {
            title: "Seamless Integration",
            description: "Works with your existing CRM and tools.",
            icon: Phone,
            image: benefitIntegration
          }].map((benefit, index) => <div key={index} className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 rounded-2xl overflow-hidden backdrop-blur-sm border border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={benefit.image} 
                    alt={benefit.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-transparent to-transparent"></div>
                </div>
                <div className="p-8">
                  <div className="w-14 h-14 bg-purple-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-purple-500/30 transition-colors">
                    <benefit.icon className="w-7 h-7 text-purple-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">{benefit.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{benefit.description}</p>
                </div>
              </div>)}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-purple-900/10 to-transparent">
        <div className="container mx-auto max-w-4xl">
          <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 rounded-3xl p-12 backdrop-blur-sm border border-purple-500/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl"></div>
            <div className="relative z-10">
              <div className="text-6xl text-purple-400 mb-6">"</div>
              <p className="text-2xl text-gray-200 mb-8 leading-relaxed italic">
                Since using Nuvia AI Reception Agents, we haven't missed a single client call. 
                It feels like having an entire front desk team that never sleeps.
              </p>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full"></div>
                <div>
                  <p className="text-white font-semibold text-lg">Emily Patel</p>
                  <p className="text-gray-400">Operations Manager, The Studio Co.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32 px-4 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={receptionFooterBg} 
            alt="Reception footer background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-purple-900/70 to-[#0a0a0f]/90"></div>
        </div>
        <div className="container mx-auto max-w-4xl text-center relative z-10">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Your Front Desk, Reinvented.
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Let Nuvia AI handle the calls while your team focuses on clients.
          </p>
          <BookingDialog>
            <Button size="lg" className="button-3d text-lg px-8 py-6">
              Try a Live Reception Demo
            </Button>
          </BookingDialog>
        </div>
      </section>

      <Footer />
    </div>;
};
export default ReceptionAgents;