import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BookingDialog from "@/components/BookingDialog";
import { Button } from "@/components/ui/button";
import { Home, Calendar, MessageCircle, Globe, TrendingUp, Clock } from "lucide-react";

const RealEstateSolutions = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-900/20 via-transparent to-transparent"></div>
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="text-center space-y-6">
            <div className="inline-block p-3 bg-emerald-500/10 rounded-2xl backdrop-blur-sm border border-emerald-500/20 mb-4">
              <Home className="w-8 h-8 text-emerald-400" />
            </div>
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-white via-emerald-200 to-emerald-400 bg-clip-text text-transparent">
              AI Voice Agents for Real Estate
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Turn missed property calls into closed deals.<br />
              Nuvia AI handles inquiries, schedules showings, and follows up — all in real time.
            </p>
            <BookingDialog>
              <Button size="lg" className="button-3d text-lg px-8 py-6">
                Book a Free Real Estate Demo
              </Button>
            </BookingDialog>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-gradient-to-br from-red-900/10 to-orange-900/10 rounded-3xl p-12 backdrop-blur-sm border border-red-500/10">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Missed Calls. Missed Buyers.
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl">
              Every unreturned call is a lost sale opportunity.<br />
              Real estate teams often juggle multiple listings, clients, and calls — and that's where our AI agents take over seamlessly.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent via-emerald-900/5 to-transparent">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
            How Nuvia AI Helps Real Estate Professionals
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: "1", title: "Answers property inquiries 24/7", icon: Clock },
              { step: "2", title: "Shares details and photos automatically via SMS or WhatsApp", icon: MessageCircle },
              { step: "3", title: "Schedules property visits and confirms availability", icon: Calendar },
              { step: "4", title: "Follows up with potential buyers intelligently", icon: TrendingUp }
            ].map((item) => (
              <div key={item.step} className="relative group">
                <div className="bg-gradient-to-br from-emerald-900/20 to-blue-900/20 rounded-2xl p-8 backdrop-blur-sm border border-emerald-500/20 hover:border-emerald-500/40 transition-all duration-300 h-full">
                  <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center mb-4 group-hover:bg-emerald-500/30 transition-colors">
                    <item.icon className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div className="text-5xl font-bold text-emerald-500/30 mb-4">{item.step}</div>
                  <p className="text-lg text-gray-200">{item.title}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
            Why Real Estate Teams Trust Nuvia AI
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                title: "24/7 Lead Capture", 
                description: "Never miss a property inquiry again, day or night.",
                icon: Clock 
              },
              { 
                title: "Smart Follow-ups", 
                description: "The AI nurtures leads until they're ready to buy.",
                icon: TrendingUp 
              },
              { 
                title: "Appointment Booking", 
                description: "Seamless sync with your Google Calendar or CRM.",
                icon: Calendar 
              },
              { 
                title: "Multi-Language Communication", 
                description: "Connect with buyers worldwide in their language.",
                icon: Globe 
              },
              { 
                title: "Measurable ROI", 
                description: "More qualified leads, less manual work, better conversions.",
                icon: TrendingUp 
              },
              { 
                title: "Instant Property Info", 
                description: "Shares listings, photos, and details automatically.",
                icon: MessageCircle 
              }
            ].map((benefit, index) => (
              <div key={index} className="bg-gradient-to-br from-emerald-900/20 to-blue-900/20 rounded-2xl p-8 backdrop-blur-sm border border-emerald-500/20 hover:border-emerald-500/40 transition-all duration-300 group">
                <div className="w-14 h-14 bg-emerald-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-500/30 transition-colors">
                  <benefit.icon className="w-7 h-7 text-emerald-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">{benefit.title}</h3>
                <p className="text-gray-300 leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Story Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-emerald-900/10 to-transparent">
        <div className="container mx-auto max-w-4xl">
          <div className="bg-gradient-to-br from-emerald-900/30 to-blue-900/30 rounded-3xl p-12 backdrop-blur-sm border border-emerald-500/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl"></div>
            <div className="relative z-10">
              <div className="text-6xl text-emerald-400 mb-6">"</div>
              <p className="text-2xl text-gray-200 mb-8 leading-relaxed italic">
                Our agents can now focus on showings while Nuvia AI handles all incoming calls and follow-ups. 
                It's like having a virtual assistant who never sleeps.
              </p>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-full"></div>
                <div>
                  <p className="text-white font-semibold text-lg">Sarah Kim</p>
                  <p className="text-gray-400">RealtyPro Group</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Automate Your Real Estate Calls with Confidence
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Let your AI assistant handle leads, inquiries, and appointments —<br />
            so you can focus on closing the next big deal.
          </p>
          <BookingDialog>
            <Button size="lg" className="button-3d text-lg px-8 py-6">
              Experience the Real Estate Demo
            </Button>
          </BookingDialog>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default RealEstateSolutions;
