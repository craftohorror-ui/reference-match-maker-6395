const LogoSection = () => {
  const logos = [
    { name: "LOGO", icon: "©" },
    { name: "EGGS", icon: "🥚" },
    { name: "THE PAAK" },
    { name: "IDEA", icon: "💡" },
    { name: "360LAB", icon: "©" },
    { name: "ECHOES", icon: "S" }
  ];

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-[#0a0a0f]">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="flex flex-wrap items-center justify-center gap-8 sm:gap-12 md:gap-16">
          {logos.map((logo) => (
            <div key={logo.name} className="flex items-center gap-2 text-foreground/80 hover:text-foreground transition-colors">
              {logo.icon && <span className="text-xl sm:text-2xl">{logo.icon}</span>}
              <span className="text-base sm:text-lg md:text-xl font-semibold tracking-wide">
                {logo.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LogoSection;
