import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-bg-new.avif";
import BookingDialog from "./BookingDialog";
import { useNavigate } from "react-router-dom";

const HeroSection = () => {
  const navigate = useNavigate();
  
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center pt-20 bg-[#0a0a0f]">
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black/50"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-12 relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-center">
          <div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 leading-tight">
              Real voices. Real results. Every call.
            </h1>
          </div>
          
          <div>
            <p className="text-sm sm:text-base md:text-lg font-semibold text-white/90 leading-relaxed mb-6 sm:mb-8">
              Experience the warmth of real conversations—powered by advanced voice agents who sound and feel human. From friendly reception to proactive outreach and real estate support, we help your business connect, engage, and grow. Join a community where every call matters and every client feels valued.
            </p>
            <div className="flex gap-4">
              <Button 
                onClick={scrollToContact}
                size="lg"
              >
                Start Now
              </Button>
              <Button 
                onClick={() => navigate('/about')}
                size="lg"
                variant="outline"
                className="text-white border-white/40 bg-white/10 backdrop-blur-sm hover:bg-white/20 hover:border-white/60 transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-white/20"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
