import { Button } from "@/components/ui/button";
import laptopImage from "@/assets/laptop-dashboard-new.avif";
import agentImage from "@/assets/agent-headset-new.avif";
import realEstateImage from "@/assets/real-estate-tech-updated.avif";

const FeatureHighlights = () => {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const features = [
    {
      tag: "RECEPTION AGENTS",
      title: "Warm welcomes, every single time",
      description: "Never miss a call or a chance to connect. Our virtual receptionists greet your customers with a friendly voice, answer questions, and make sure every caller feels valued.",
      image: laptopImage,
      buttonText: "Learn more"
    },
    {
      tag: "OUTREACH AGENTS",
      title: "Reach out, grow faster",
      description: "Let our AI agents handle follow-ups, schedule calls, and nurture leads—so your team can focus on building relationships and closing deals.",
      image: agentImage,
      buttonText: "Explore"
    },
    {
      tag: "REAL ESTATE SOLUTIONS",
      title: "Effortless client conversations",
      description: "From first inquiry to final walkthrough, our agents streamline every step—making it easy for clients to connect, book, and get answers fast.",
      image: realEstateImage,
      buttonText: "Start now"
    }
  ];

  return (
    <div className="relative" id="features">
      <div className="container mx-auto px-4 sm:px-6 py-12 sm:py-16 lg:py-20 bg-[#0a0a0f]">
        <p className="text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-4 sm:mb-6">FEATURE HIGHLIGHTS</p>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-8 sm:mb-12 lg:mb-16">
          AI agents, real human connection
        </h2>
      </div>

      <div className="relative" style={{ height: `${features.length * 100}vh` }}>
        {features.map((feature, index) => (
          <section 
            key={index} 
            className={`sticky top-0 h-screen flex items-center justify-center bg-[#0a0a0f] ${
              index > 0 ? 'rounded-t-[24px] sm:rounded-t-[40px]' : ''
            } overflow-hidden transition-all duration-300`}
            style={{
              zIndex: index + 1,
            }}
          >
            <div className="container mx-auto px-4 sm:px-6 flex items-center justify-center">
              <div className="max-w-5xl w-full aspect-square max-h-[85vh] rounded-3xl relative overflow-hidden p-8 sm:p-12 lg:p-16 flex items-center">
                {/* Dreamy bright blur background with dark corners */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/30 via-purple-500/20 to-gray-900/90 backdrop-blur-3xl"></div>
                <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400/40 rounded-full blur-[120px]"></div>
                <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-600/30 rounded-full blur-[120px]"></div>
                
                <div className="relative z-10 grid md:grid-cols-2 gap-8 lg:gap-12 items-center w-full">
                  <div className="flex items-center justify-center">
                    <div className="rounded-2xl overflow-hidden w-full max-w-sm shadow-2xl shadow-blue-500/20">
                      <img src={feature.image} alt={feature.title} className="w-full h-[400px] object-cover" />
                    </div>
                  </div>
                  <div className="flex flex-col justify-center space-y-6">
                    <p className="text-xs sm:text-sm text-gray-300 uppercase tracking-wider font-semibold">{feature.tag}</p>
                    <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight">
                      {feature.title}
                    </h3>
                    <p className="text-base sm:text-lg text-gray-200 leading-relaxed">
                      {feature.description}
                    </p>
                    <Button 
                      onClick={scrollToContact}
                      size="lg"
                    >
                      {feature.buttonText}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </section>
        ))}
      </div>
    </div>
  );
};

export default FeatureHighlights;
