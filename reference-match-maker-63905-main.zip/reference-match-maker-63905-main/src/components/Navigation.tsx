import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronDown, Menu, X } from "lucide-react";
import BookingDialog from "./BookingDialog";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  const scrollToSection = (id: string) => {
    if (!isHomePage) {
      window.location.href = `/#${id}`;
      return;
    }
    
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
      setIsOpen(false);
    }
  };

  const solutions = [
    { name: "Reception Agents", href: "/solutions/reception-agents" },
    { name: "Outreach Agents", href: "/solutions/outreach-agents" },
    { name: "Real Estate Solutions", href: "/solutions/real-estate" },
  ];

  const support = [
    { name: "FAQ", href: "/faq" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0f]/95 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-white rounded-lg flex items-center justify-center">
              <div className="w-3 h-3 sm:w-4 sm:h-4 bg-[#0a0a0f] transform rotate-45"></div>
            </div>
            <span className="text-lg sm:text-xl font-semibold text-white tracking-tight">Nuvia AI</span>
          </div>
          
          <div className="hidden lg:flex items-center gap-8">
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1.5 text-gray-300 hover:text-white transition-colors text-sm font-bold">
                Solutions <ChevronDown className="w-4 h-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {solutions.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link to={item.href}>
                      {item.name}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Link to="/about" className="text-gray-300 hover:text-white transition-colors text-sm font-bold">About</Link>
            <Link to="/blog" className="text-gray-300 hover:text-white transition-colors text-sm font-bold">Blog</Link>
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1.5 text-gray-300 hover:text-white transition-colors text-sm font-bold">
                Support <ChevronDown className="w-4 h-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {support.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link to={item.href}>
                      {item.name}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <div className="flex items-center gap-2">
            <BookingDialog>
              <Button>
                Book demo
              </Button>
            </BookingDialog>

            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden text-white">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[280px] sm:w-[350px]">
                <nav className="flex flex-col gap-6 mt-8">
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground mb-3">SOLUTIONS</p>
                    <div className="flex flex-col gap-3">
                      {solutions.map((item) => (
                        <Link
                          key={item.name}
                          to={item.href}
                          onClick={() => setIsOpen(false)}
                          className="text-foreground hover:text-primary transition-colors text-left"
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                  
                  <Link
                    to="/about"
                    onClick={() => setIsOpen(false)}
                    className="text-foreground hover:text-primary transition-colors text-left"
                  >
                    About
                  </Link>
                  
                  <Link
                    to="/blog"
                    onClick={() => setIsOpen(false)}
                    className="text-foreground hover:text-primary transition-colors text-left"
                  >
                    Blog
                  </Link>
                  
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground mb-3">SUPPORT</p>
                    <div className="flex flex-col gap-3">
                      {support.map((item) => (
                        <Link
                          key={item.name}
                          to={item.href}
                          onClick={() => setIsOpen(false)}
                          className="text-foreground hover:text-primary transition-colors text-left"
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
