const FAQSection = () => {
  const faqs = [
    {
      question: "How do voice agents support teams?",
      answer: "Voice agents take care of repetitive calls, so your team can focus on building relationships and growing your business. They sound natural, answer questions, and make every client feel valued."
    },
    {
      question: "Can I personalize the agent's replies?",
      answer: "Yes! We'll help you shape every script and response, so your voice agent always sounds like a true extension of your brand and values."
    },
    {
      question: "Who gets the most from voice agents?",
      answer: "Real estate, service providers, and any business that values smooth, human-like conversations with clients see the biggest impact from our solutions."
    },
    {
      question: "Is setup quick and easy?",
      answer: "Absolutely. We walk you through each step, making onboarding simple and stress-free. Most businesses are ready to go in just a few days."
    },
    {
      question: "How is client data protected?",
      answer: "Your clients' privacy is our priority. All calls are encrypted and stored securely, so you can trust that sensitive information stays safe."
    },
    {
      question: "What support is available post-launch?",
      answer: "We're here for you with ongoing support, updates, and training. Whenever you need help or want to make changes, just reach out—our team is ready to assist."
    }
  ];

  return (
    <section className="py-16 sm:py-20 lg:py-24 bg-[#0a0a0f]" id="faq">
      <div className="container mx-auto px-4 sm:px-6 max-w-7xl">
        <p className="text-xs sm:text-sm text-gray-400 uppercase tracking-widest mb-6 font-medium">YOUR TOP QUESTIONS, ANSWERED</p>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
          Voice agents, demystified for business
        </h2>
        <p className="text-base sm:text-lg text-gray-300 mb-16 max-w-3xl leading-relaxed">
          Wondering how voice agents fit your business? Explore clear, friendly answers to help you get started and grow with confidence.
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-transparent">
              <h3 className="text-xl font-bold text-white mb-4 leading-snug">
                {faq.question}
              </h3>
              <p className="text-base text-gray-300 leading-relaxed">
                {faq.answer}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
