import { Button } from "@/components/ui/button";
import avatarImage from "@/assets/testimonial-avatar-new.avif";

const TestimonialSection = () => {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-[#0a0a0f]" id="testimonials">
      <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 xl:px-24 py-10 sm:py-14 lg:py-16 rounded-2xl bg-gradient-to-b from-[#1a1a2e] via-[#16162a] to-[#0a0a0f] mb-12 sm:mb-16 lg:mb-20">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8 lg:gap-12 max-w-7xl mx-auto">
          <div className="flex-1 max-w-3xl">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6">
              Let's grow your business together
            </h2>
            <p className="text-base sm:text-lg lg:text-xl text-gray-300 leading-relaxed">
              Ready for more time, happier clients, and real results? Our friendly AI voice agents handle calls, book appointments, and connect with your customers—so you can focus on what you do best. Join a community of businesses streamlining their workflow and watch your growth take off.
            </p>
          </div>
          <Button 
            onClick={scrollToContact}
            size="lg"
          >
            Get started
          </Button>
        </div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6">

        <div className="max-w-5xl mx-auto">
          <blockquote className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-medium text-foreground mb-8 sm:mb-12 leading-relaxed">
            "With Nuvia AI, our calls are answered instantly and every client feels valued. We've reclaimed hours each week, and the natural conversations have truly elevated our service. Seamless, reliable, and a game-changer for our business. Highly recommend to anyone ready to grow."
          </blockquote>
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 sm:gap-8">
            <div className="flex items-center gap-4">
              <img src={avatarImage} alt="Jordan Ellis" className="w-12 h-12 sm:w-16 sm:h-16 rounded-full object-cover" />
              <div>
                <p className="text-foreground font-semibold">Jordan Ellis</p>
                <p className="text-sm text-muted-foreground font-bold">Client Success Lead</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <span className="text-xl sm:text-2xl">©</span>
              <span className="text-lg sm:text-xl font-semibold">360LAB</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;
