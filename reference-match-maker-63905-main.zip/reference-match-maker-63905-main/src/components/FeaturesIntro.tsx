import { Button } from "@/components/ui/button";
import receptionistImage from "@/assets/receptionist-device.avif";
import teamImage from "@/assets/real-estate-new.avif";

const FeaturesIntro = () => {
  const scrollToFeatures = () => {
    const element = document.getElementById("features");
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section className="py-12 sm:py-16 lg:py-20" id="about">
      <div className="container mx-auto px-4 sm:px-6 bg-[#0a0a0f]">
        <div className="max-w-3xl mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 sm:mb-6">
            AI agents, real human connection
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground">
            Meet the next generation of voice agents—always friendly, always available. We help you create seamless, personal experiences that make every customer feel valued and every business moment count.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
          <div className="bg-[#0a0a0f] rounded-lg overflow-hidden">
            <img src={receptionistImage} alt="AI Receptionist" className="w-full h-48 sm:h-64 object-cover" />
            <div className="p-6 sm:p-8">
              <p className="text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-3">Receptionist</p>
              <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-3 sm:mb-4">
                Never miss a call again
              </h3>
              <p className="text-sm sm:text-base text-muted-foreground mb-6 font-bold">
                Greet every caller with warmth and efficiency. Our AI receptionists answer questions, route calls, and ensure your business is always open for conversation.
              </p>
              <Button 
                onClick={scrollToFeatures}
              >
                Learn more
              </Button>
            </div>
          </div>

          <div className="bg-[#0a0a0f] rounded-lg overflow-hidden">
            <img src={teamImage} alt="Real Estate Solutions" className="w-full h-48 sm:h-64 object-cover" />
            <div className="p-6 sm:p-8">
              <p className="text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-3">Real estate</p>
              <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-3 sm:mb-4">
                Effortless lead nurturing
              </h3>
              <p className="text-sm sm:text-base text-muted-foreground mb-6 font-bold">
                Stay connected with every prospect. Our AI agents follow up, book appointments, and keep your business growing—no matter the hour.
              </p>
              <Button 
                onClick={scrollToFeatures}
              >
                Discover
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesIntro;
