import { useState, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Facebook, Twitter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import BookingDialog from "./BookingDialog";

const ContactSection = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    company: "",
    message: ""
  });

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Basic validation
    if (!formData.fullName || !formData.email || !formData.message) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields (Name, Email, Message)",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('send-booking-email', {
        body: {
          name: formData.fullName,
          email: formData.email,
          businessName: formData.company || "Not provided",
          contactNo: formData.phone || "Not provided",
          service: "general-inquiry",
          message: formData.message,
        },
      });

      if (error) throw error;

      toast({
        title: "Message sent!",
        description: "Thank you for reaching out. We'll get back to you within 24 hours.",
      });

      // Reset form
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        company: "",
        message: ""
      });
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-[#0a0a0f]" id="contact">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center mb-8 sm:mb-12">
          <p className="text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-4">LET'S TALK</p>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 sm:mb-6">
            Connect with a voice expert
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Curious how voice agents can elevate your business? Reach out and let's explore solutions together. We're here to help you grow.
          </p>
          <div className="flex justify-center mt-8">
            <BookingDialog>
              <Button size="lg">
                Book a Call Now
              </Button>
            </BookingDialog>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 sm:gap-12 max-w-6xl mx-auto">
          <div className="rounded-lg p-6 sm:p-8 bg-gradient-to-b from-[#1a1a2e] via-[#16162a] to-[#0a0a0f]">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-2">
                    Full Name *
                  </label>
                  <Input 
                    placeholder="Your name" 
                    className="bg-background border-border h-12" 
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-2">
                    Work Email *
                  </label>
                  <Input 
                    type="email" 
                    placeholder="email@website.com" 
                    className="bg-background border-border h-12" 
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-2">
                    Phone Number
                  </label>
                  <Input 
                    placeholder="1 (555) 000-0000" 
                    className="bg-background border-border h-12" 
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-2">
                    Company Name
                  </label>
                  <Input 
                    placeholder="Company name" 
                    className="bg-background border-border h-12" 
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-wide mb-2">
                  How can we help? *
                </label>
                <Textarea 
                  placeholder="Type your message..." 
                  className="bg-background border-border min-h-32" 
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  required
                />
              </div>

              <Button 
                type="submit" 
                size="lg"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Sending..." : "Send a Message"}
              </Button>
            </form>
          </div>

          <div className="rounded-lg p-6 sm:p-8 bg-gradient-to-b from-[#1a1a2e] via-[#16162a] to-[#0a0a0f]">
            <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-4 sm:mb-6">
              Get in touch
            </h3>
            <p className="text-sm sm:text-base text-muted-foreground mb-6 sm:mb-8">
              Have questions about our human-like voice agents or want to see how they fit your business? Our team is ready to chat and guide you.
            </p>

            <div className="space-y-6 mb-8 sm:mb-12">
              <div>
                <p className="text-xs sm:text-sm font-bold text-muted-foreground mb-2">Email</p>
                <a href="mailto:hello@nuviaai.com" className="text-foreground font-medium hover:text-primary transition-colors">
                  hello@nuviaai.com
                </a>
              </div>
              <div>
                <p className="text-xs sm:text-sm font-bold text-muted-foreground mb-2">WhatsApp No</p>
                <a href="https://wa.me/15551234567" className="text-foreground font-medium hover:text-primary transition-colors">
                  +1 (555) 123-4567
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg sm:text-xl font-bold text-foreground mb-4">
                Join our community
              </h4>
              <p className="text-sm sm:text-base text-muted-foreground mb-6">
                Follow us for the latest on voice AI, business tips, and inspiring client stories.
              </p>
              <div className="flex gap-4">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-primary transition-colors" aria-label="Facebook">
                  <Facebook className="w-6 h-6" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-primary transition-colors" aria-label="Twitter">
                  <Twitter className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
